"""
main.py

Phase 1 entry point. This does NOT connect to any real search source yet —
it just confirms that the project structure works, and gives a tiny preview
of the scoring and intent-detection pieces we've already built, using
made-up example data.
"""

from intent_terms import contains_website_intent
from scorer import calculate_score, label_for_score


def main():
    print("=" * 50)
    print("Website Opportunity Finder — Phase 1 starter")
    print("=" * 50)
    print()
    print("Project is running successfully.")
    print()

    # A made-up example post, just to prove intent_terms.py works.
    example_post = "Hi all, I'm looking for someone to build a website for my small consulting business."
    print(f"Example post: \"{example_post}\"")
    print(f"Detected website intent: {contains_website_intent(example_post)}")
    print()

    # A made-up example set of signals, just to prove scorer.py works.
    example_signals = {
        "explicit_website_request": True,
        "explicit_landing_page_request": False,
        "no_website_found": True,
        "active_social_presence": True,
        "public_contact_available": True,
        "established_business": False,
    }
    score = calculate_score(example_signals)
    label = label_for_score(score)
    print(f"Example signals: {example_signals}")
    print(f"Example opportunity score: {score}/100 ({label})")
    print()
    print("Next step: Phase 2 — connect a real, permitted search source.")


if __name__ == "__main__":
    main()
