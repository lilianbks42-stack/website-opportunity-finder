"""
leads.py

Defines the shape of a "lead" and a basic way to save leads to a CSV file.
In Phase 5 this may grow into a proper Google Sheets integration, but a
simple CSV writer is enough to get started and is easy to inspect by hand.
"""

import csv
import os

LEAD_FIELDS = [
    "Business",
    "Person",
    "Source",
    "Source URL",
    "Original Post/Text",
    "Website",
    "Industry",
    "Location",
    "Intent",
    "Opportunity Score",
    "Score Label",
    "Reason",
    "Public Contact",
    "Recommended Service",
    "Status",
]


def new_lead(**kwargs) -> dict:
    """
    Builds a lead dictionary with all expected fields, defaulting any
    field not provided to an empty string. This keeps every lead row
    consistent even before every field is being collected.
    """
    lead = {field: "" for field in LEAD_FIELDS}
    for key, value in kwargs.items():
        if key in lead:
            lead[key] = value
    return lead


def save_leads(leads: list, filepath: str = "data/leads.csv") -> str:
    """
    Appends a list of lead dicts to a CSV file, creating it (with a
    header row) if it doesn't exist yet. Returns the filepath written to.
    """
    file_exists = os.path.isfile(filepath)

    with open(filepath, mode="a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=LEAD_FIELDS)
        if not file_exists:
            writer.writeheader()
        for lead in leads:
            writer.writerow(lead)

    return filepath
