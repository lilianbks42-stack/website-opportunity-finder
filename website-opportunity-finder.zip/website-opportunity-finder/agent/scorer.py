"""
scorer.py

Calculates an "opportunity score" (0-100) for a prospective lead, based on
the signals we've gathered about them. This mirrors the scoring model from
the project plan. Later phases will feed this function real data collected
by the search + analysis steps; for now it's a standalone, testable piece
of logic.
"""

SCORE_WEIGHTS = {
    "explicit_website_request": 35,
    "explicit_landing_page_request": 40,
    "no_website_found": 25,
    "active_social_presence": 15,
    "public_contact_available": 10,
    "established_business": 10,
}

MAX_SCORE = 100


def calculate_score(signals: dict) -> int:
    """
    signals: a dict of booleans, e.g.
        {
            "explicit_website_request": True,
            "explicit_landing_page_request": False,
            "no_website_found": True,
            "active_social_presence": True,
            "public_contact_available": True,
            "established_business": False,
        }

    Returns an integer score capped at MAX_SCORE.
    """
    total = 0
    for key, weight in SCORE_WEIGHTS.items():
        if signals.get(key):
            total += weight
    return min(total, MAX_SCORE)


def label_for_score(score: int) -> str:
    """
    Converts a numeric score into the human-readable label used in the
    project plan.
    """
    if score >= 90:
        return "HOT"
    if score >= 70:
        return "WORTH REVIEW"
    if score >= 50:
        return "POTENTIAL"
    return "LOW PRIORITY"
