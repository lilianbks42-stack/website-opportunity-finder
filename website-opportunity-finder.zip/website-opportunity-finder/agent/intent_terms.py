"""
intent_terms.py

A starter list of phrases that signal someone publicly expressing
commercial intent around wanting a website / landing page / online presence.

This is intentionally simple for Phase 1 (just a list of strings). In a
later phase this will be used by the search + intent-detection step to
match against public posts/results, and can be expanded with synonyms,
fuzzy matching, or an AI classifier.
"""

WEBSITE_INTENT_PHRASES = [
    "looking for a website developer",
    "need a landing page",
    "need someone to build a website",
    "looking for a web designer",
    "need a website for my business",
    "looking for someone to create a website",
    "website developer needed",
    "how do i get my business online",
    "looking for someone to build my website",
    "need an online presence",
    "i'm looking for someone to build a website",
    "i need a landing page for my business",
    "can anyone recommend a web designer",
    "we need a website for our company",
    "i need help creating an online presence",
    "who can build a simple website for my business",
    "looking for someone to create a landing page",
]


def contains_website_intent(text: str) -> bool:
    """
    Very simple starter check: does the given text contain any of our
    known intent phrases (case-insensitive)?

    This is a placeholder for Phase 1/2. Later phases can replace or
    extend this with smarter matching (fuzzy matching, embeddings, or an
    AI model call) without changing how the rest of the agent uses it.
    """
    lowered = text.lower()
    return any(phrase in lowered for phrase in WEBSITE_INTENT_PHRASES)
