"""
test_scorer.py

Basic tests for the opportunity scoring logic. Run with:
    python -m pytest
or, without pytest installed, these can be read as documentation of the
expected behavior.
"""

import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "agent"))

from scorer import calculate_score, label_for_score  # noqa: E402


def test_no_signals_scores_zero():
    assert calculate_score({}) == 0


def test_all_signals_caps_at_max():
    all_signals = {
        "explicit_website_request": True,
        "explicit_landing_page_request": True,
        "no_website_found": True,
        "active_social_presence": True,
        "public_contact_available": True,
        "established_business": True,
    }
    # 35+40+25+15+10+10 = 135, but should cap at 100
    assert calculate_score(all_signals) == 100


def test_example_scenario():
    signals = {
        "explicit_website_request": True,
        "no_website_found": True,
        "active_social_presence": True,
        "public_contact_available": True,
    }
    # 35 + 25 + 15 + 10 = 85
    assert calculate_score(signals) == 85


def test_labels():
    assert label_for_score(95) == "HOT"
    assert label_for_score(75) == "WORTH REVIEW"
    assert label_for_score(55) == "POTENTIAL"
    assert label_for_score(20) == "LOW PRIORITY"


if __name__ == "__main__":
    test_no_signals_scores_zero()
    test_all_signals_caps_at_max()
    test_example_scenario()
    test_labels()
    print("All tests passed.")
